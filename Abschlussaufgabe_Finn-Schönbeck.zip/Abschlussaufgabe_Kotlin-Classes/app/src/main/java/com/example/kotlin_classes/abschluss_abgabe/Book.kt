package com.example.kotlin_classes.abschluss_abgabe

data class Book(
    val title: String,
    val author: String,
    val genre: Genre,
    val status: BookStatus,
)

