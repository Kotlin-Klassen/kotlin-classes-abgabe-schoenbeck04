# Kotlin-Classes
Data-, Enum-, Nested-, Sealed-Klassen

Hier finden sie alles was Sie zum lösen der Aufgaben brauchen.

Bei Fragen gerne uns eine Mail Schreiben:
mhottmann@stud.hs-heilbronn.de
phottmann@stud.hs-heilbronn.de
jwilleke@stud.hs-heilbronn.de
